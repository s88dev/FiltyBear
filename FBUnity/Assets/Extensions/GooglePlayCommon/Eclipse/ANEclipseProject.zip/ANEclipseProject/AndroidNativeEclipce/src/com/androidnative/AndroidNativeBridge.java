package com.androidnative;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.androidnative.billing.core.BillingManager;
import com.androidnative.billing.util.Base64;
import com.androidnative.billing.util.Base64DecoderException;
import com.androidnative.features.AppInfoLoader;
import com.androidnative.features.CameraAPI;
import com.androidnative.features.ImmersiveMode;
import com.androidnative.features.common.AddressBookManager;
import com.androidnative.features.common.AndroidNativeUtility;
import com.androidnative.features.notifications.LocalNotificationsController;
import com.androidnative.features.social.common.SocialGate;
import com.androidnative.features.social.instagram.AnInstagram;
import com.androidnative.features.social.twitter.ANTwitter;
import com.androidnative.gcm.ANCloudMessageService;
import com.androidnative.gms.analytics.V4GoogleAnalytics;
import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.network.RealTimeMultiplayerController;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

@SuppressLint("NewApi")
public class AndroidNativeBridge extends UnityPlayerActivity {

	private static AndroidNativeBridge inst = null;

	

	/**
	 * Tag used on log messages.
	 */
	public static final String TAG = "AndroidNative";
	

	public static final String ANDROID_APP_EVENT_LISTNER = "AndroidApp";
	
	/**
	 * Splitters.
	 */
	public static final String UNITY_SPLITTER = "|";
	public static final String UNITY_EOF = "endofline";
	


	private FileOutputStream fos;

	

	// --------------------------------------
	// INITIALIZE
	// --------------------------------------

	@Override
	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		inst = this;

	}

	public static AndroidNativeBridge GetInstance() {
		return inst;
	}

	// --------------------------------------
	// Override
	// --------------------------------------

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		//native api
		try {
			try {
				UnityPlayer.UnitySendMessage(ANDROID_APP_EVENT_LISTNER, "onActivityResult", String.valueOf(requestCode) + AndroidNativeBridge.UNITY_SPLITTER + String.valueOf(resultCode));
				CameraAPI.GetInstance().onActivityResult(requestCode, resultCode, data);

			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative onActivityResult NoClassDefFoundError", ex.getMessage());
		}
		
		//billing
		try {
			try {

				BillingManager.GetInstance().handleActivityResult(requestCode, resultCode, data);

			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative onActivityResult NoClassDefFoundError", ex.getMessage());
		}
		
		//google play
		try {
			try {
				if (GameClientManager.isStarted()) {
					GameClientManager.GetInstance().onActivityResult(requestCode, resultCode, data);
				}
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.e("AndroidNative onActivityResult NoClassDefFoundError", ex.getMessage());
		}
		
		
		super.onActivityResult(requestCode, resultCode, data);

	}

	@Override
	public void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		
		Log.d("AndroidNative", "onNewIntent: ");
		UnityPlayer.UnitySendMessage(ANDROID_APP_EVENT_LISTNER, "onNewIntent", "");

		//google play
		try {
			try {
				
				if (GameClientManager.isStarted()) {
					GameClientManager.GetInstance().onNewIntent(intent);
				}	
			} catch (Throwable ex) {
				Log.d("AndroidNative", "onNewIntent has failed");
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onNewIntent NoClassDefFoundError" + ex.getMessage());
		}
		
		//twitter
		try {
			try {
				
				ANTwitter.GetInstance().SetIntent(intent);
			} catch (Throwable ex) {
				Log.d("AndroidNative", "onNewIntent has failed");
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onNewIntent NoClassDefFoundError" + ex.getMessage());
		}
		
		
		
		
	}

	@Override
	public void onDestroy() {
		super.onDestroy();

		try {
			BillingManager.GetInstance().dispose();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onDestroy: " + ex.getMessage());
		}
	}

	@Override
	protected void onStart() {
		
		try {
			
			UnityPlayer.UnitySendMessage(ANDROID_APP_EVENT_LISTNER, "onStart", "");
			
			if (GameClientManager.isStarted()) {
				GameClientManager.GetInstance().onStart();
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onStart NoClassDefFoundError: " + ex.getMessage());
		}
		
		
		super.onStart();
		
	}
	@Override
	protected void onStop() {
		
		//native 
		try {
			UnityPlayer.UnitySendMessage(ANDROID_APP_EVENT_LISTNER, "onStop", "");


		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onStop NoClassDefFoundError: " + ex.getMessage());
		}
		
		//google play
		try {
			if (GameClientManager.isStarted()) {
				Log.d("AndroidNative", "isStarted: ");
				GameClientManager.GetInstance().onStop();
			}

		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onStop NoClassDefFoundError: " + ex.getMessage());
		}
		
		super.onStop();

	}
	
	

	@Override
	public void onWindowFocusChanged(boolean arg0) {
		super.onWindowFocusChanged(arg0);

		try {

			ImmersiveMode.onWindowFocusChanged(arg0);

		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "onWindowFocusChanged: " + ex.getMessage());
		}
	}

	// --------------------------------------
	// Internal API
	// --------------------------------------

	// --------------------------------------
	// Google Cloud
	// --------------------------------------

	public void listStates() {
		try {
			GameClientManager.GetInstance().listStates();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError listStates: " + ex.getMessage());
		}
		
	}

	public void updateState(String stateKey, String data) {
		try {
			GameClientManager.GetInstance().updateState(Integer.parseInt(stateKey), data);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError updateState: " + ex.getMessage());
		}
		
	}

	public void deleteState(String stateKey) {
		try {
			GameClientManager.GetInstance().deleteState(Integer.parseInt(stateKey));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError deleteState: " + ex.getMessage());
		}
		
	}

	public void loadState(String stateKey) {
		try {
			GameClientManager.GetInstance().loadState(Integer.parseInt(stateKey));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadState: " + ex.getMessage());
		}
		
	}

	public void resolveState(String stateKey, String resolvedData,String resolvedVersion) {
		try {
			GameClientManager.GetInstance().resolveState(Integer.parseInt(stateKey),
					resolvedData, resolvedVersion);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resolveState: " + ex.getMessage());
		}
		
	}
	
	
	// --------------------------------------
	// Saved Games 
	// --------------------------------------
		
	public void showSavedGamesUI(String title, String maxNumberOfSavedGamesToShow) {
		try {
			GameClientManager.GetInstance().showSavedGamesUI(title, Integer.parseInt(maxNumberOfSavedGamesToShow));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showSavedGamesUI: " + ex.getMessage());
		}
		
		
	}
	
	public void createNewSpanShot(String name, String description, String ImageData, String Data)  {
		try {
			GameClientManager.GetInstance().createNewSpanShot(name, description, ImageData, Data);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError createNewSpanShot: " + ex.getMessage());
		}
	}
	
	public void resolveSpanShotConflict(String index)  {
		try {
			GameClientManager.GetInstance().resolveSnapshotsConflict(Integer.parseInt(index));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resolveSpanShotConflict: " + ex.getMessage());
		}
	}

		

	// --------------------------------------
	// Google Cloud Message
	// --------------------------------------

	public void GCMRgisterDevice(String senderId) {
		try {
			ANCloudMessageService.GetInstance().registerDevice(senderId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GCMRgisterDevice: " + ex.getMessage());
		}
		
	}

	public void GCMLoadLastMessage() {
		try {
			ANCloudMessageService.GetInstance().LoadLastMessage();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GCMLoadLastMessage: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// Google Play Services
	// --------------------------------------

	public void playServiceInit(String scopes) {
		try {
			GameClientManager.GetInstance().InitPlayService(scopes);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceInit: " + ex.getMessage());
		}
		
		
	}

	public void playServiceConnect() {
		try {
			GameClientManager.GetInstance().sighIn();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: " + ex.getMessage());
		}
		
	}
	
	public void playServiceConnect(String accountName) {
		try {
			GameClientManager.GetInstance().sighIn(accountName);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceConnect: " + ex.getMessage());
		}
		
	}
	
	
	public void getToken() {
		try {
			GameClientManager.GetInstance().getToken();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError getToken: " + ex.getMessage());
		}
		
	}
	public void getToken(String accountName, String scope) {
		try {
			GameClientManager.GetInstance().getToken(accountName, scope);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError getToken: " + ex.getMessage());
		}
		
	}

	public void invalidateToken(String token) {
		try {
			GameClientManager.GetInstance().invalidateToken(token);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError invalidateToken: " + ex.getMessage());
		}
		
	}
	
	public void loadGoogleAccountNames() {
		try {
			GameClientManager.GetInstance().loadGoogleAccountNames();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadGoogleAccountNames: " + ex.getMessage());
		}
		
	}
	
	
	public void clearDefaultAccount() {
		try {
			GameClientManager.GetInstance().clearDefaultAccount();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError clearDefaultAccount: " + ex.getMessage());
		}
		
		
	}
	
	public void revokeAccessAndDisconnect() {
		try {
			GameClientManager.GetInstance().revokeAccessAndDisconnect();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError revokeAccessAndDisconnect: " + ex.getMessage());
		}
		
	}
	
	

	public void playServiceDisconnect() {
		try {
			GameClientManager.GetInstance().disconnect();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError playServiceDisconnect: " + ex.getMessage());
		}
		
	}

	public void showAchivments() {
		try {
			GameClientManager.GetInstance().showAchivmentsUI();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showAchivments: " + ex.getMessage());
		}
		
	}

	public void showLeaderBoards() {
		try {
			GameClientManager.GetInstance().showLeaderBoardsUI();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoards: " + ex.getMessage());
		}
		
	}

	public void showLeaderBoard(String leaderboardName) {
		try {
			String leaderboardId = getStringResourceByName(leaderboardName);
			showLeaderBoardById(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoard" + ex.getMessage());
		}
		
	}

	public void showLeaderBoardById(String leaderboardId) {
		try {
			GameClientManager.GetInstance().showLeaderBoardUI(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showLeaderBoardById: " + ex.getMessage());
		}
		
	}

	public void loadConnectedPlayers() {
		try {
			GameClientManager.GetInstance().loadConnectedPlayers();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadConnectedPlayers: " + ex.getMessage());
		}
		
	}

	public void submitScore(String leaderboardName, String score) {
		String leaderboardId = getStringResourceByName(leaderboardName);
		submitScoreById(leaderboardId, score);
	}

	public void submitScoreById(String leaderboardId, String score) {
		try {
			GameClientManager.GetInstance().submitScore(leaderboardId, Long.parseLong(score));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError submitScoreById: " + ex.getMessage());
		}
		
	}

	public void loadLeaderBoards() {
		try {
			GameClientManager.GetInstance().loadLeaderBoards();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadLeaderBoards: " + ex.getMessage());
		}
		
	}
	
	
	public void updatePlayerScore(String leaderboardId, String span, String leaderboardCollection) {
		try {
			GameClientManager.GetInstance().UpdatePlayerScore(leaderboardId, Integer.parseInt(span), Integer.parseInt(leaderboardCollection));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError updatePlayerScore: " + ex.getMessage());
		}
	
	}
	

	public void loadPlayerCenteredScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		try {
			GameClientManager.GetInstance().loadPlayerCenteredScores(leaderboardId,
					Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection),
					Integer.parseInt(maxResults));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadPlayerCenteredScores: " + ex.getMessage());
		}
		
	}

	public void loadTopScores(String leaderboardId, String span,
			String leaderboardCollection, String maxResults) {
		try {
			GameClientManager.GetInstance().loadTopScores(leaderboardId,
					Integer.parseInt(span),
					Integer.parseInt(leaderboardCollection),
					Integer.parseInt(maxResults));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadTopScores: " + ex.getMessage());
		}
	
	}

	public void reportAchievement(String achievementName) {
		
		String achievementId = getStringResourceByName(achievementName);
		reportAchievementById(achievementId);
	}

	public void reportAchievementById(String achievementId) {
		try {
			GameClientManager.GetInstance().reportAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError reportAchievementById: " + ex.getMessage());
		}
		
	}

	public void revealAchievement(String achievementName) {
		Log.d("AndroidNative", "achievementName: " + achievementName);
		String achievementId = getStringResourceByName(achievementName);
		
		Log.d("AndroidNative", "achievementId: " + achievementId);
		revealAchievementById(achievementId);
	}

	public void revealAchievementById(String achievementId) {
		try {
			GameClientManager.GetInstance().revealAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError 	GameClientManager.GetInstance().revealAchievement(achievementId);: " + ex.getMessage());
		}
	
	}

	public void incrementAchievement(String achievementName, String numsteps) {
		String achievementId = getStringResourceByName(achievementName);
		incrementAchievementById(achievementId, numsteps);
	}

	public void incrementAchievementById(String achievementId, String numsteps) {
		try {
			GameClientManager.GetInstance().incrementAchievement(achievementId,
					Integer.parseInt(numsteps));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError incrementAchievementById: " + ex.getMessage());
		}
		
	}

	public void loadAchievements() {
		try {
			GameClientManager.GetInstance().loadAchievements();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadAchievements: " + ex.getMessage());
		}
		
	}
	
	public void resetAchievement(String achievementId) {
		try {
			GameClientManager.GetInstance().resetAchievement(achievementId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resetAchievement: " + ex.getMessage());
		}
		
	}
	
	public void resetAllAchievements() {
		try {
			GameClientManager.GetInstance().resetAllAchievements();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError resetAllAchievements: " + ex.getMessage());
		}
		
	}
	
	
	public void resetLeaderBoard(String leaderboardId) {
		try {
			GameClientManager.GetInstance().resetLeaderBoard(leaderboardId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GameClientManager.GetInstance().resetLeaderBoard(leaderboardId);: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// Gifts
	// --------------------------------------

	public void sendGiftRequest(String type, String playload, String requestLifetimeDays, String icon, String description) {
		try {
			GameClientManager.GetInstance().sendGiftRequest(type, playload, requestLifetimeDays, icon, description);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendGiftRequest: " + ex.getMessage());
		}
		
	}

	public void showRequestAccepDialog() {
		try {
			GameClientManager.GetInstance().showRequestAccepDialog();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GameClientManager.GetInstance().showRequestAccepDialog();: " + ex.getMessage());
		}
		
	}
	
	public void acceptRequests(String ids) {
		try {
			GameClientManager.GetInstance().acceptRequests(ids);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError acceptRequests: " + ex.getMessage());
		}
		
	}
	 
	public void dismissRequest(String ids) {
		try {
			GameClientManager.GetInstance().dismissRequest(ids);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError dismissRequest: " + ex.getMessage());
		}
		
	}
	
	
	public void loadPlayerInfo(String playerId) {
		try {
			GameClientManager.GetInstance().loadPlayerInfo(playerId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadPlayerInfo: " + ex.getMessage());
		}
		
	}
	
	
	// --------------------------------------
	// QUESTS AND EVENTS
	// --------------------------------------
	
	public void sumbitEvent(String eventId, String count) {
		try {
			GameClientManager.GetInstance().sumbitEvent(eventId, Integer.valueOf(count));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sumbitEvent: " + ex.getMessage());
		}
		
	}
	
	public void loadEvents() {
		try {
			GameClientManager.GetInstance().loadEvents();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadEvents: " + ex.getMessage());
		}
		
	}
	
	
	
	public void showSelectedQuests(String questSelectors) {
		try {
			GameClientManager.GetInstance().showSelectedQuests(questSelectors);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showSelectedQuests: " + ex.getMessage());
		}
		
	}
	
	public void acceptQuest(String questId) {
		try {
			GameClientManager.GetInstance().acceptQuest(questId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError acceptQuest: " + ex.getMessage());
		}
		
	}
	
	
	public void loadQuests(String questSelectors, String sortOrder) {
		try {
			GameClientManager.GetInstance().loadQuests(questSelectors, Integer.valueOf(sortOrder));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError loadQuests: " + ex.getMessage());
		}
		
	}
	
	
	
	// --------------------------------------
	// RTM
	// --------------------------------------
	
	public void RTMFindMatch(String minPlayers, String maxPlayers, String bitMask) {
		try {
			RealTimeMultiplayerController.GetInstance().findMatch(Integer.valueOf(minPlayers), Integer.valueOf(maxPlayers), Integer.valueOf(bitMask));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError RTMFindMatch: " + ex.getMessage());
		}
		
	}
	
	public void sendDataToAll(String data, String sendType) {
		try {
			RealTimeMultiplayerController.GetInstance().sendDataToAll(data, Integer.valueOf(sendType));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendDataToAll: " + ex.getMessage());
		}
		
	}

	public void sendDataToPlayers(String data, String players, String sendType) {
		try {
			RealTimeMultiplayerController.GetInstance().sendDataToPlayers(data, players, Integer.valueOf(sendType));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError sendDataToPlayers: " + ex.getMessage());
		}
		
	}
	
	public void showWaitingRoomIntent() {
		try {
			RealTimeMultiplayerController.GetInstance().showWaitingRoomIntent();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showWaitingRoomIntent: " + ex.getMessage());
		}
		
	}
	
	public void leaveRoom() {
		try {
			RealTimeMultiplayerController.GetInstance().leaveRoom();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError leaveRoom: " + ex.getMessage());
		}
		
	}
	
	public void acceptInviteToRoom(String invId) {
		try {
			RealTimeMultiplayerController.GetInstance().acceptInviteToRoom(invId);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError acceptInviteToRoom: " + ex.getMessage());
		}
		
	}
	
	public void showInvitationBox()  {
		try {
			RealTimeMultiplayerController.GetInstance().showInvitationBox();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError showInvitationBox: " + ex.getMessage());
		}
		
	}
	
	

	
	
	public void invitePlayers(String minPlayers, String maxPlayers) {
		try {
			RealTimeMultiplayerController.GetInstance().invitePlayers(Integer.valueOf(minPlayers), Integer.valueOf(maxPlayers));
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError invitePlayers: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// BILLING
	// --------------------------------------

	public void connectToBilling(String ids, String base64EncodedPublicKey) {
		try {
			
			BillingManager.GetInstance().SetActivity(this);

			ArrayList<String> products = new ArrayList<String>();
			String[] result = ids.split(",");

			for (String id : result) {
				products.add(id);
			}

			BillingManager.GetInstance().connect(products, base64EncodedPublicKey);
			
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void retrieveProducDetails() {
		try {
			BillingManager.GetInstance().retrieveProducDetails();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void consume(String SKU) {
		try {
			BillingManager.GetInstance().consume(SKU);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void purchase(String SKU, String developerPayload) {
		try {
			BillingManager.GetInstance().purchase(SKU, developerPayload);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}

	public void subscribe(String SKU, String developerPayload) {
		try {
			BillingManager.GetInstance().subscribe(SKU, developerPayload);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError: " + ex.getMessage());
		}
	}



	// --------------------------------------
	// OTHER FEATURES
	// --------------------------------------

	public void enableImmersiveMode() {
		ImmersiveMode.enableImmersiveMode();

	}

	public void loadAddressBook() {
		AddressBookManager.GetInstance().load();
	}

	public void requestCurrentAppLaunchNotificationId() {
		LocalNotificationsController.GetInstance().requestCurrentAppLaunchNotificationId();
	}
	
	
	public void ScheduleLocalNotification(String title, String message, String seconds, String id) {
		int sec = Integer.parseInt(seconds);
		int nId = Integer.parseInt(id);
		LocalNotificationsController.GetInstance().scheduleNotification(title,message, sec, nId);
	}
	
	public void canselLocalNotification(String id) {
		int nId = Integer.parseInt(id);
		LocalNotificationsController.GetInstance().canselNotification(nId);
	}

	public void ShowToastNotification(String text, String duration) {
		Context context = getApplicationContext();

		Toast toast = Toast.makeText(context, text, Integer.parseInt(duration));
		toast.show();
	}

	public void LoadPackageInfo() {
		AppInfoLoader.LoadPackageInfo();
	}

	// --------------------------------------
	// Analytics
	// --------------------------------------

	public void startAnalyticsTracking() {
		try {
			try {
				
				V4GoogleAnalytics.GetInstance().startAnalyticsTracking(this);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError startAnalyticsTracking: " + ex.getMessage());
		}
		
	}

	public void SetTrackerID(String trackingID) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().SetTracker(trackingID);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SetTrackerID: " + ex.getMessage());
		}
		
		
	}

	public void SendView(String appScreen) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().SendView(appScreen);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendView: " + ex.getMessage());
		}
		
	}

	public void SendView() {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().SendView();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendView: " + ex.getMessage());
		}
		
	}

	public void SendEvent(String category, String action, String label, String value) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().sendEvent(category, action, label,
						value);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendEvent: " + ex.getMessage());
		}
		
		
	}

	public void SendEvent(String category, String action, String label,String value, String key, String val) {

		try {
			try {
				V4GoogleAnalytics.GetInstance().sendEvent(category, action, label, 	value, key, val);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendEvent: " + ex.getMessage());
		}
		
	}

	public void SetKey(String key, String value) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().setKey(key, value);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SetKey: " + ex.getMessage());
		}
		
	}

	public void ClearKey(String key) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().clearKey(key);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError ClearKey: " + ex.getMessage());
		}
		
	}

	public void SendTiming(String category, String intervalInMilliseconds,String name, String label) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().sendTiming(category,
						intervalInMilliseconds, name, label);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendTiming: " + ex.getMessage());
		}
		
		
	}

	public void CreateTransaction(String transactionId, String affiliation, String revenue, String tax, String shipping, String currencyCode) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().CreateTransaction(transactionId,
						affiliation, revenue, tax, shipping, currencyCode);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError CreateTransaction: " + ex.getMessage());
		}
		
		
	}

	public void CreateItem(String transactionId, String name, String sku,String category, String price, String quantity, String currencyCode) {
		
		try {
			try {
				V4GoogleAnalytics.GetInstance().CreateItem(transactionId, name, sku,
						category, price, quantity, currencyCode);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError CreateItem: " + ex.getMessage());
		}
		
		
	}

	public void SetLogLevel(String lvl) {
		try {
			try {
				V4GoogleAnalytics.GetInstance().SetLogLevel(Integer.parseInt(lvl));
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SetLogLevel: " + ex.getMessage());
		}
		
		
	}

	public void SetDryRun(String mode) {
		
		try {
			try {
				boolean m = false;
				if (mode.equals("true")) {
					m = true;
				} else {
					m = false;
				}
				
				V4GoogleAnalytics.GetInstance().setDryRun(m);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "SetDryRun SetLogLevel: " + ex.getMessage());
		}
		
	}
	
	public void enableAdvertisingIdCollection(String mode) {
		try {
			try {
				boolean m = false;
				if (mode.equals("true")) {
					m = true;
				} else {
					m = false;
				}
				
				V4GoogleAnalytics.GetInstance().enableAdvertisingIdCollection(m);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "SetDryRun SetLogLevel: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// Social
	// --------------------------------------

	public void StartShareIntent(String caption, String message, String subject, String filters) {
		try {
			SocialGate.Share(caption, message, subject, filters);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError StartShareIntent: " + ex.getMessage());
		}
		
		
		
	}

	public void StartShareIntentMedia(String caption, String message, String subject, String media, String filters) {
		try {
			SocialGate.Share(caption, message, subject, media, filters);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError StartShareIntentMedia: " + ex.getMessage());
		}
		
	}
	
	public void SendMailWithImage(String caption, String message,  String subject, String email, String media) {
		try {
			SocialGate.SendMailWithImage(caption, message, subject, email, media);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SocialGate.SendMailWithImage(caption, message, subject, email, media);: " + ex.getMessage());
		}
		
	}
	
	public void SendMail(String caption, String message,  String subject, String email) {
		try {
			SocialGate.SendMail(caption, message, subject, email);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SendMail: " + ex.getMessage());
		}
		
	}
	
	// --------------------------------------
	// Twitter
	// --------------------------------------

	public void TwitterInit(String consumer_key, String consumer_secret) {
		try {
			ANTwitter.GetInstance().Init(consumer_key, consumer_secret, this);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError TwitterInit: " + ex.getMessage());
		}
		
	}

	public void AuthificateUser() {
		try {
			ANTwitter.GetInstance().AuthificateUser();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError AuthificateUser: " + ex.getMessage());
		}
		
	}

	public void LoadUserData() {
		try {
			ANTwitter.GetInstance().LoadUserData();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError LoadUserData: " + ex.getMessage());
		}
		
	}

	public void TwitterPost(String status) {
		try {
			ANTwitter.GetInstance().Twitt(status);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError ANTwitter.GetInstance().Twitt(status);: " + ex.getMessage());
		}
		
	}

	public void TwitterPostWithImage(String status, String data) throws IOException, Base64DecoderException {
		
		try {
			Log.d("AndroidNative", "TwitterPostWithImage: ");
			byte[] byteArray = Base64.decode(data);

			File tempFile;
			tempFile = new File(this.getCacheDir(), "twitter_post_image");
			fos = new FileOutputStream(tempFile);
			fos.write(byteArray);

			ANTwitter.GetInstance().Twitt(status, tempFile);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError TwitterPostWithImage: " + ex.getMessage());
		}
		

	}

	public void LogoutFromTwitter() {
		try {
			ANTwitter.GetInstance().logoutFromTwitter();
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError LogoutFromTwitter: " + ex.getMessage());
		}
		
	}

	// --------------------------------------
	// Instagram
	// --------------------------------------

	public void InstagramPostImage(String data, String caption) {
		try {
			AnInstagram.Share(data, caption);
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError InstagramPostImage: " + ex.getMessage());
		}
		
	}

	
	// --------------------------------------
	// Utils
	// --------------------------------------
	
	public void isPackageInstalled(String packagename) {
		try {
			try {
				AndroidNativeUtility.GetInstance().isPackageInstalled(packagename);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError isPackageInstalled: " + ex.getMessage());
		}
		
	}
	
	public void runPackage(String packagename) {
		try {
			try {
				AndroidNativeUtility.GetInstance().runPackage(packagename);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError runPackage: " + ex.getMessage());
		}

	}
	
	
	public void SaveToGalalry(String ImageData, String name) {
		try {
			try {
				CameraAPI.GetInstance().SaveToGalalry(ImageData, name);
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError SaveToGalalry: " + ex.getMessage());
		}
		
	}
	
	
	public void InitCameraAPI(String folderName, String maxSize, String mode) {
		try {
			try {
				CameraAPI.GetInstance().Init(folderName, Integer.parseInt(maxSize) , Integer.parseInt(mode));
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError InitCameraAPI: " + ex.getMessage());
		}
		
		
		
	}
	


	public void GetImageFromGallery() {
		try {
			try {
				CameraAPI.GetInstance().GetImageFromGallery();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GetImageFromGallery: " + ex.getMessage());
		}
		
	}
	
	
	
	public void GetImageFromCamera() {
		
		try {
			try {
				CameraAPI.GetInstance().GetImageFromCamera();
			} catch (Exception ex) {
				ex.printStackTrace();
				Log.d("AndroidNative", "Error: " + ex.getMessage());
			}
		} catch (NoClassDefFoundError ex) {
			Log.d("AndroidNative", "NoClassDefFoundError GetImageFromCamera: " + ex.getMessage());
		}
		
		
	}
	


	// --------------------------------------
	// Private Methods
	// --------------------------------------

	

	private String getStringResourceByName(String aString) {
		String packageName = getPackageName();
		int resId = getResources()
				.getIdentifier(aString, "string", packageName);
		return getString(resId);
	}
	
	
	


}
