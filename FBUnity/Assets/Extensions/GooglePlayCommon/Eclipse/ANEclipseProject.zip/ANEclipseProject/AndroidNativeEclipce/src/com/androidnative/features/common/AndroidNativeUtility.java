package com.androidnative.features.common;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.androidnative.AndroidNativeBridge;
import com.unity3d.player.UnityPlayer;

public class AndroidNativeUtility {
	public static final String UTILITY_LISTENER = "AndroidNativeUtility";
	

	private static AndroidNativeUtility _instance = null;


	public static AndroidNativeUtility GetInstance() {
		if (_instance == null) {
			_instance = new AndroidNativeUtility();
		}

		return _instance;
	}
	

	@SuppressLint("NewApi")
	public void isPackageInstalled(String packagename) {
	    PackageManager pm = AndroidNativeBridge.GetInstance().getPackageManager();
	    try {
	        pm.getPackageInfo(packagename, PackageManager.GET_ACTIVITIES);
	        UnityPlayer.UnitySendMessage(UTILITY_LISTENER, "OnPacakgeFound", packagename );
	    } catch (NameNotFoundException e) {
	    	UnityPlayer.UnitySendMessage(UTILITY_LISTENER, "OnPacakgeNotFound", packagename );
	    }
	}
	
	@SuppressLint("NewApi")
	public void runPackage(String packagename) {
		PackageManager pm = AndroidNativeBridge.GetInstance().getPackageManager();
		Intent intent = pm.getLaunchIntentForPackage(packagename);
		AndroidNativeBridge.GetInstance().startActivity(intent);
	}
	
	

	public static Activity GetLauncherActivity() {
		return UnityPlayer.currentActivity;
	}
	
	
	public static Context GetApplicationContex() {
		return GetLauncherActivity().getApplicationContext();
	}
}
