package com.androidnative.gms.network;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.core.NewGameHelper;
import com.androidnative.gms.listeners.network.AN_OnInvitationReceivedListener;
import com.androidnative.gms.listeners.network.AN_RealTimeMessageReceivedListener;
import com.androidnative.gms.listeners.network.AN_RoomStatusUpdateListener;
import com.androidnative.gms.listeners.network.AN_RoomUpdateListener;
import com.androidnative.gms.utils.AnUtility;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesActivityResultCodes;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.Multiplayer;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.unity3d.player.UnityPlayer;

public class RealTimeMultiplayerController {
	
	
	protected NewGameHelper mHelper;

	private static RealTimeMultiplayerController _instance = null;
	public Room currentRoom;  
	
	
	

	public static RealTimeMultiplayerController GetInstance() {
		if (_instance == null) {
			_instance = new RealTimeMultiplayerController();
		}

		return _instance;
	}
	
	
	// --------------------------------------
	// DELAGETD FROM GCM
	// --------------------------------------
	
	public void SetGameHelper(NewGameHelper helper) {
		mHelper  = helper;
	}
    
	
	public void OnStop() {
		//leaveRoom("OnGameCanceled");
	}
	
	
	public void onConnected(Bundle connectionHint)  {
		

		 if(connectionHint != null) {
			 Invitation inv = connectionHint.getParcelable(Multiplayer.EXTRA_INVITATION);
			 if(inv != null) {
				 Log.d(GameClientManager.TAG, "we go some invitations");
				 UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnInvitationReceived", inv.getInvitationId());
			 }
		 }

		
		Games.Invitations.registerInvitationListener(mHelper.getGoogleApiClient(), new AN_OnInvitationReceivedListener());

	}
	
	
	public void onActivityResult(int request, int response, Intent data) {
		switch (request) {
        case GameClientManager.RC_SELECT_PLAYERS:        	
        	handleSelectPlayersResult(response, data);
        	break;
        case GameClientManager.RC_INVITATION_INBOX:
        	handleInvitationInboxResult(response, data);
        	break;
        case GameClientManager.RC_WAITING_ROOM:
        	
        	switch(response) {
	        	case Activity.RESULT_OK: 
	        	case Activity.RESULT_CANCELED:
	        		
	        		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnWatingRoomIntentClosed", String.valueOf(request) + GameClientManager.UNITY_SPLITTER + String.valueOf(response) );
	        		break;
	        		
	        	case GamesActivityResultCodes.RESULT_LEFT_ROOM:
	        		leaveRoom();
	        		break;
        	}
        
        	break;
		}
	}
	
	
	
	// --------------------------------------
	// PUBLIC METHODS
	// --------------------------------------
	
	@SuppressLint("NewApi")
	public void invitePlayers(int minPlayers, int maxPlayers) {
		Intent intent = Games.RealTimeMultiplayer.getSelectOpponentsIntent(mHelper.getGoogleApiClient(), minPlayers, maxPlayers);
		AnUtility.GetLauncherActivity().startActivityForResult(intent, GameClientManager.RC_SELECT_PLAYERS);
	}
	
	@SuppressLint("NewApi")
	public void showInvitationBox() {
		Intent intent = Games.Invitations.getInvitationInboxIntent(mHelper.getGoogleApiClient());
		AnUtility.GetLauncherActivity().startActivityForResult(intent, GameClientManager.RC_INVITATION_INBOX);
	}
	
	
	public void findMatch(int minPlayers, int maxPlayers, int bitMask) {
		Log.d("GAME_CLIENT_MANAGER findMatch!!!", "dida FIND MATCH");
		Bundle autoMatchCriteria = RoomConfig.createAutoMatchCriteria(minPlayers, maxPlayers, bitMask);
		RoomConfig.Builder roomConfigBuilder = makeBasicRoomConfigBuilder();
		roomConfigBuilder.setAutoMatchCriteria(autoMatchCriteria);
		Games.RealTimeMultiplayer.create(mHelper.getGoogleApiClient(), roomConfigBuilder.build());
	}
	
	private RoomConfig.Builder makeBasicRoomConfigBuilder() {
		return RoomConfig.builder(new AN_RoomUpdateListener()).setMessageReceivedListener(new AN_RealTimeMessageReceivedListener()).setRoomStatusUpdateListener(new AN_RoomStatusUpdateListener());
	}
	
	@SuppressLint("NewApi")
	public void showWaitingRoomIntent() {
		// minimum number of players required for our game
		// For simplicity, we require everyone to join the game before we start
		// it (this is signaled by Integer.MAX_VALUE).
		final int MIN_PLAYERS = Integer.MAX_VALUE;
		Intent data = Games.RealTimeMultiplayer.getWaitingRoomIntent(mHelper.getGoogleApiClient(), currentRoom, MIN_PLAYERS);

		// show waiting room UI
		AnUtility.GetLauncherActivity().startActivityForResult(data, GameClientManager.RC_WAITING_ROOM);
	}
	
	
	// --------------------------------------
	// PRIVATE METHODS
	// --------------------------------------
	
	
	public void sendDataToAll(String data, int sendType) {
		byte[] stateData = ConvertStringToMultiplayerData(data);
				
		sendMessage(stateData, currentRoom.getParticipants(), sendType);
	}

	public void sendDataToPlayers(String data, String players, int sendType) {
		byte[] stateData = ConvertStringToMultiplayerData(data);
		
		
		
		ArrayList<Participant> participants =  new ArrayList<Participant>();
		
		if(players != null && players.length() > 0) {
			for(String id : players.split(GameClientManager.UNITY_SPLITTER)) {
				
				for (Participant p : currentRoom.getParticipants()) {
					if(p.getPlayer().getPlayerId().equals(id)) {
						participants.add(p);
					}
				}
			}
		}
			
		
		sendMessage(stateData, participants, sendType);
		
	}
	
	
	private void sendMessage(byte[] data, ArrayList<Participant> participants, int sendType) {
		
		if(currentRoom == null) {
			return;
		}

		Player player = Games.Players.getCurrentPlayer(mHelper.getGoogleApiClient());
		
		for (Participant p : currentRoom.getParticipants()) {
			if (p.getParticipantId().equals(player.getPlayerId()))
				continue;
			if (p.getStatus() != Participant.STATUS_JOINED)
				continue;
			
			
			
			if(sendType == 0) {
				Games.RealTimeMultiplayer.sendReliableMessage(mHelper.getGoogleApiClient(), null, data, currentRoom.getRoomId(), p.getParticipantId());
			} else {
				Games.RealTimeMultiplayer.sendUnreliableMessage(mHelper.getGoogleApiClient(), data, currentRoom.getRoomId(), p.getParticipantId());
			}
			
			
		}
	}
	
	
	
	// --------------------------------------
	// EVENTS
	// --------------------------------------
	
	public void OnRoomUpdated(Room room) {
		Log.d(GameClientManager.TAG, "OnRoomUpdated total players:" + room.getParticipantIds().size());
		currentRoom = room;
		
		
		
		StringBuilder info = new StringBuilder();
		
		info.append(room.getRoomId() );
		info.append(GameClientManager.UNITY_SPLITTER);
		
		info.append(room.getCreatorId() );
		info.append(GameClientManager.UNITY_SPLITTER);
		
		String ParticipantIds = "";
		
		
		for(Participant participant : room.getParticipants()) {

		
			ParticipantIds += participant.getParticipantId() +  ",";

			if(participant.getPlayer() != null) {
				ParticipantIds +=  participant.getPlayer().getPlayerId() + ",";
				GameClientManager.GetInstance().loadPlayerInfo(participant.getPlayer().getPlayerId());
			} else {
				ParticipantIds += "-1" + ",";
			}
			ParticipantIds += String.valueOf(participant.getStatus()) + ",";
			
			
		}
		ParticipantIds += GameClientManager.UNITY_EOF;
		
		info.append(ParticipantIds);
		info.append(GameClientManager.UNITY_SPLITTER);

		info.append(room.getStatus());
		info.append(GameClientManager.UNITY_SPLITTER);
		info.append(room.getCreationTimestamp());
		info.append(GameClientManager.UNITY_SPLITTER);
		
				
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnRoomUpdate", info.toString());
		
		
	}
	
	public void leaveRoom() {
		if (currentRoom != null) {
			Games.RealTimeMultiplayer.leave(mHelper.getGoogleApiClient(), new AN_RoomUpdateListener(), currentRoom.getRoomId());
			currentRoom = null;
		}	
		
	}
	
	
	// Handle the result of the invitation inbox UI, where the player can pick
	// an invitation
	// to accept. We react by accepting the selected invitation, if any.
	private void handleInvitationInboxResult(int response, Intent data) {
		Log.d(GameClientManager.TAG, "handleInvitationInboxResult+");
		if (response != Activity.RESULT_OK) {
			return;
		}

		
		Invitation inv = data.getExtras().getParcelable(Multiplayer.EXTRA_INVITATION);

		// accept invitation
		acceptInviteToRoom(inv.getInvitationId());
	}

	
	// / Accept the given invitation.
	public void acceptInviteToRoom(String invId) {
		
		Log.d(GameClientManager.TAG, "acceptInviteToRoom+");
		
		RoomConfig.Builder roomConfigBuilder = makeBasicRoomConfigBuilder();
		roomConfigBuilder.setInvitationIdToAccept(invId);
		Games.RealTimeMultiplayer.join(mHelper.getGoogleApiClient(), roomConfigBuilder.build());
	}
		
	
	private void handleSelectPlayersResult(int response, Intent data) {
		if (response == Activity.RESULT_OK) {
			
			Log.d(GameClientManager.TAG, "handleSelectPlayersResult+");

			// get the invite list 
			final ArrayList<String> invitees = data.getStringArrayListExtra(Games.EXTRA_PLAYER_IDS);
		
			Log.d(GameClientManager.TAG, "invitees: " + invitees.size());
			// get the automatch criteria
			Bundle autoMatchCriteria = null;
			int minAutoMatchPlayers = data.getIntExtra(Multiplayer.EXTRA_MIN_AUTOMATCH_PLAYERS, 0);
			int maxAutoMatchPlayers = data.getIntExtra(Multiplayer.EXTRA_MAX_AUTOMATCH_PLAYERS, 0);
			
			if (minAutoMatchPlayers > 0 || maxAutoMatchPlayers > 0) {
				autoMatchCriteria = RoomConfig.createAutoMatchCriteria(minAutoMatchPlayers, maxAutoMatchPlayers, 0);
			}
	
			
			RoomConfig.Builder rtmConfigBuilder = makeBasicRoomConfigBuilder();
			rtmConfigBuilder.addPlayersToInvite(invitees);
			if (autoMatchCriteria != null) {
				rtmConfigBuilder.setAutoMatchCriteria(autoMatchCriteria);
			}
			
			
			Log.d(GameClientManager.TAG, "create room");
			Games.RealTimeMultiplayer.create(mHelper.getGoogleApiClient(), rtmConfigBuilder.build());

		}
		
		UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PLAY_RTM_LISTENER, "OnInvitationBoxUiClosed",  "10001" + GameClientManager.UNITY_SPLITTER  +String.valueOf(response));
	}

	
	private static byte[] ConvertStringToMultiplayerData(String data) {
		String[] array = data.split(",");
		List<Byte> l = new ArrayList<Byte>();
		for (String b : array) {
			int temp_param = Integer.valueOf(b);
			byte byte_value = (byte)temp_param;
			l.add(Byte.valueOf(String.valueOf(byte_value)));
		}

		Byte[] B = l.toArray(new Byte[l.size()]);

		byte[] stateData = new byte[B.length];
		for (int i = 0; i < B.length; i++) {
			stateData[i] = B[i];
		}

		return stateData;
	}

	
	

	
	
}
