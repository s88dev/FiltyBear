package com.androidnative.gms.listeners.games;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.achievement.Achievements.UpdateAchievementResult;
import com.unity3d.player.UnityPlayer;

public class AchievementsUpdateListner implements ResultCallback<Achievements.UpdateAchievementResult> {

	@Override
	public void onResult(UpdateAchievementResult res) {
		Log.d("AndroidNative", "Status: " + res.getStatus().getStatusCode() + " achivment: "+ res.getAchievementId());

		StringBuilder info = new StringBuilder();
		info.append(res.getStatus().getStatusCode());
		info.append(GameClientManager.UNITY_SPLITTER);
		info.append(res.getAchievementId());
		
		
		GameClientManager.GetInstance().loadAchievements(false);
		UnityPlayer.UnitySendMessage(GameClientManager.PlAY_SERVICE_LISTNER_NAME, "OnAchievementUpdated", info.toString());
		
	}

}
