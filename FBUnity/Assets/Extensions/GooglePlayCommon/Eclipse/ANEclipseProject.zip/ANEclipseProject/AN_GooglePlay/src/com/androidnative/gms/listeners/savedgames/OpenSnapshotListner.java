package com.androidnative.gms.listeners.savedgames;

import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.utils.Base64;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.Snapshots.OpenSnapshotResult;
import com.unity3d.player.UnityPlayer;


public class OpenSnapshotListner implements ResultCallback<OpenSnapshotResult> {

	@Override
	public void onResult(OpenSnapshotResult result) {
		 int status = result.getStatus().getStatusCode();
		 
		 StringBuilder  builder = new StringBuilder();
		 builder.append(status);
		 
		 
		 if(status == GamesStatusCodes.STATUS_OK) {
			 
			 Snapshot  snapshot = result.getSnapshot();
			 
			 builder.append(GameClientManager.UNITY_SPLITTER);
			 builder.append(snapshot.getMetadata().getTitle());
			 builder.append(GameClientManager.UNITY_SPLITTER);
			 builder.append(snapshot.getMetadata().getLastModifiedTimestamp());
			 builder.append(GameClientManager.UNITY_SPLITTER);
			 builder.append(snapshot.getMetadata().getDescription());
			 builder.append(GameClientManager.UNITY_SPLITTER);
			 builder.append(snapshot.getMetadata().getCoverImageUrl());
			 builder.append(GameClientManager.UNITY_SPLITTER);
			 String data = Base64.encode(snapshot.readFully());
			 builder.append(data);
			 
			 
	         UnityPlayer.UnitySendMessage(GameClientManager.GOOGLE_PlAY_SAVED_GAMES_LISTNER_NAME, "OnSavedGamePicked", builder.toString());
	
		 } 
		 
		 
		 if (status == GamesStatusCodes.STATUS_SNAPSHOT_CONFLICT) {
			 GameClientManager.GetInstance().snedConflict(result);
		 }
		
	}

}
