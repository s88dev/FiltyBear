package com.androidnative.gms.ad;

import android.util.Log;


import com.androidnative.gms.core.GameClientManager;
import com.androidnative.gms.utils.AnUtility;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.unity3d.player.UnityPlayer;

public class BannerAdListner extends AdListener{

	private  String bannerID;
	private  AdView adView = null;
	
	private boolean costil = true;
	
	public BannerAdListner(AdView ad, int id) {
		adView = ad;
		
		bannerID = Integer.toString(id);
			
	}
	
	
	 public void onAdLoaded() {
		 if(costil) {
			 AdRequest adRequest = new AdRequest.Builder().build();
		     adView.loadAd(adRequest);
		     costil = false;
		    
		 } else {
			 
			 Log.d("AndroidNative", "OnBannerAdLoaded: ");
			 
			 StringBuilder result = new StringBuilder();
		     result.append(bannerID);
		     result.append(GameClientManager.UNITY_SPLITTER);
		     result.append(adView.getAdSize().getWidthInPixels( AnUtility.GetLauncherActivity() ));
		     result.append(GameClientManager.UNITY_SPLITTER);
		     result.append(adView.getAdSize().getHeightInPixels( AnUtility.GetLauncherActivity() ));


			UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnBannerAdLoaded",  result.toString());
		 }
		
	 }
	 
	 public void onAdFailedToLoad(int errorCode) {
		Log.d("AndroidNative", "OnBannerAdFailedToLoad: ");
		UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnBannerAdFailedToLoad", bannerID);
		 
		 
	 }
	  
	 public void onAdOpened() {
		Log.d("AndroidNative", "OnBannerAdOpened: ");
		UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnBannerAdOpened", bannerID);
	 }
	 
	 public void onAdClosed() {
		Log.d("AndroidNative", "OnBannerAdClosed: ");
		UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnBannerAdClosed", bannerID);
		
	 }
	 
	 public void onAdLeftApplication() {
		Log.d("AndroidNative", "OnBannerAdLeftApplication: ");
		UnityPlayer.UnitySendMessage(ANMobileAd.AD_MOB_LISTNER_NAME, "OnBannerAdLeftApplication", bannerID);
	 }
}
